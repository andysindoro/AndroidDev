package id.ac.purbaya.projectcataloguemovie.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import id.ac.purbaya.projectcataloguemovie.R;
import id.ac.purbaya.projectcataloguemovie.adapter.MovieCardAdapter;
import id.ac.purbaya.projectcataloguemovie.loader.AllMovieAsyncTaskLoader;
import id.ac.purbaya.projectcataloguemovie.model.Movie;

import java.util.ArrayList;


public class AllMovieCardFragment extends Fragment implements LoaderManager.LoaderCallbacks<ArrayList<Movie>> {

    RecyclerView rvCategory;
    private MovieCardAdapter adapter;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_all_movie_card, container, false);

        final EditText edtJudul = view.findViewById(R.id.edtJudul);

        rvCategory = view.findViewById(R.id.cardMovies);
        ArrayList<Movie> list = new ArrayList<>();
        rvCategory.setLayoutManager(new LinearLayoutManager(view.getContext()));

        adapter = new MovieCardAdapter(view.getContext());

        adapter.setListMovie(list);
        rvCategory.setAdapter(adapter);


        Button btnCari = view.findViewById(R.id.btnCari);
        edtJudul.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (keyEvent.getAction() == KeyEvent.ACTION_UP) {
                    String judul = edtJudul.getText().toString();

                    Bundle bundle = new Bundle();
                    bundle.putString("KEY_WORD", judul);
                    getLoaderManager().restartLoader(0, bundle, AllMovieCardFragment.this);
                }

                return false;
            }
        });

        btnCari.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String judul = edtJudul.getText().toString();

                Bundle bundle = new Bundle();
                bundle.putString("KEY_WORD", judul);
                getLoaderManager().restartLoader(0, bundle, AllMovieCardFragment.this);
            }
        });

        String judul = edtJudul.getText().toString();
        Bundle bundle = new Bundle();
        bundle.putString("KEY_WORD", judul);
        getLoaderManager().initLoader(0, bundle, this);
        return view;


    }

    @NonNull
    @Override
    public Loader<ArrayList<Movie>> onCreateLoader(int i, @Nullable Bundle bundle) {
        String keyword = "";
        if (bundle != null) {
            keyword = bundle.getString("KEY_WORD");
        }
        return new AllMovieAsyncTaskLoader(getContext(), keyword);
    }


    @Override
    public void onLoadFinished(@NonNull Loader<ArrayList<Movie>> loader, ArrayList<Movie> movies) {
        adapter.setListMovie(movies);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onLoaderReset(@NonNull Loader<ArrayList<Movie>> loader) {
        adapter.setListMovie(null);
    }


}
