package id.ac.purbaya.projectcataloguemovie.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import id.ac.purbaya.projectcataloguemovie.R;
import id.ac.purbaya.projectcataloguemovie.model.Movie;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {
    private Context context;
    private ArrayList<Movie> listMoview;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Movie item);
    }

    private ArrayList<Movie> getListMovie() {
        return listMoview;
    }

    public void setListMoview(ArrayList<Movie> listMoview) {
        this.listMoview = listMoview;
    }


    public MovieAdapter(Context context, OnItemClickListener listener) {
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemRow = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_movie, parent, false);
        return new MovieViewHolder(itemRow);
    }


    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {
        holder.bind(listMoview.get(position),listener);
    }

    @Override
    public int getItemCount() {
        return getListMovie().size();
    }

    class MovieViewHolder extends RecyclerView.ViewHolder {
        TextView tvJudul;
        TextView tvDesc;
        TextView tvDateRelease;
        ImageView imgPoster;

        MovieViewHolder(View itemView) {
            super(itemView);
            tvJudul = itemView.findViewById(R.id.txtJudul);
            tvDesc = itemView.findViewById(R.id.txtDesc);
            tvDateRelease = itemView.findViewById(R.id.txtTanggal);
            imgPoster = itemView.findViewById(R.id.imageView2);
        }

        private void bind(final Movie item, final OnItemClickListener listener) {
            tvJudul.setText(item.getTitle());
            tvDateRelease.setText(item.getDateRelase());
            String desc = item.getOverview();
            if (desc.length() >= 100) {
                desc = desc.substring(0, 100);
            }
            tvDesc.setText(desc);
            String url = "http://image.tmdb.org/t/p/w185" + item.getPoster();
            Glide.with(context)
                    .load(url)
                    .into(imgPoster);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(item);
                }
            });
        }
    }
}
