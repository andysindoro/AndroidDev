package id.ac.purbaya.projectcataloguemovie.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import id.ac.purbaya.projectcataloguemovie.DetailMovieActivity;
import id.ac.purbaya.projectcataloguemovie.R;
import id.ac.purbaya.projectcataloguemovie.adapter.MovieGridAdapter;
import id.ac.purbaya.projectcataloguemovie.loader.UpcomingAsyncLoader;
import id.ac.purbaya.projectcataloguemovie.model.Movie;

import java.util.ArrayList;

public class UpcomingGridFragment extends Fragment implements LoaderManager.LoaderCallbacks<ArrayList<Movie>> {

    RecyclerView rvCategory;
    private MovieGridAdapter adapter;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_upcoming, container, false);

        rvCategory = view.findViewById(R.id.listMovies);
        ArrayList<Movie> list = new ArrayList<>();
        rvCategory.setLayoutManager(new LinearLayoutManager(view.getContext()));

        adapter = new MovieGridAdapter(view.getContext(), new MovieGridAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Movie ml) {
                Intent detail=new Intent(getContext(),DetailMovieActivity.class);
                detail.putExtra("IDM",ml.getIdMovie());
                detail.putExtra("JUDUL",ml.getTitle());
                startActivity(detail);
            }
        });

        adapter.setListMoview(list);
        rvCategory.setAdapter(adapter);
        Bundle bundle = new Bundle();
        getLoaderManager().initLoader(0, bundle, this);
        return view;


    }

    @NonNull
    @Override
    public Loader<ArrayList<Movie>> onCreateLoader(int i, @Nullable Bundle bundle) {
        return new UpcomingAsyncLoader(getContext());
    }


    @Override
    public void onLoadFinished(@NonNull Loader<ArrayList<Movie>> loader, ArrayList<Movie> movies) {
        adapter.setListMoview(movies);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onLoaderReset(@NonNull Loader<ArrayList<Movie>> loader) {
        adapter.setListMoview(null);
    }


}