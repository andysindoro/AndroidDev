package id.ac.purbaya.projectcataloguemovie.fragment;


import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import id.ac.purbaya.projectcataloguemovie.R;
import id.ac.purbaya.projectcataloguemovie.adapter.MovieCardAdapter;
import id.ac.purbaya.projectcataloguemovie.helper.DatabaseHelper;
import id.ac.purbaya.projectcataloguemovie.helper.FavoriteHelper;
import id.ac.purbaya.projectcataloguemovie.model.Movie;

import java.util.ArrayList;

public class FavoriteFragment extends Fragment  {
    private RecyclerView rvMovie;
    private ProgressBar progressBar;
    private ArrayList<Movie> movieList;

    private FavoriteHelper helper;
    private MovieCardAdapter adapter;
    public FavoriteFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       View view= inflater.inflate(R.layout.fragment_favorite, container, false);
       rvMovie=view.findViewById(R.id.rv_movies);
       rvMovie.setLayoutManager(new LinearLayoutManager(view.getContext()));
       rvMovie.setHasFixedSize(true);

       progressBar=view.findViewById(R.id.progressbar);
       helper=new FavoriteHelper(view.getContext());
       helper.open();

        movieList=new ArrayList<>();
       adapter=new MovieCardAdapter(view.getContext());
       adapter.setListMovie(movieList);
       rvMovie.setAdapter(adapter);

       new LoadMovieAsyc().execute();

       return view;
    }

    private class LoadMovieAsyc extends AsyncTask<Void, Void,ArrayList<Movie>>{


        @Override
        protected ArrayList<Movie> doInBackground(Void... voids) {
            return helper.query();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            if(movieList.size()>0){
                movieList.clear();
            }
        }

        @Override
        protected void onPostExecute(ArrayList<Movie> movies) {
            super.onPostExecute(movies);
            progressBar.setVisibility(View.GONE);
            movieList=new ArrayList<>();
            movieList.addAll(movies);
            adapter.setListMovie(movies);
            adapter.notifyDataSetChanged();

            if(movies.size()==0){
                Snackbar.make(rvMovie, "Favorite Movie Kosong", Snackbar.LENGTH_SHORT).show();
            }
        }
    }

}
