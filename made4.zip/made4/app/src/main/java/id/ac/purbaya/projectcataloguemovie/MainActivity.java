package id.ac.purbaya.projectcataloguemovie;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

import id.ac.purbaya.projectcataloguemovie.adapter.ViewPagerAdapter;
import id.ac.purbaya.projectcataloguemovie.fragment.AllMovieCardFragment;
import id.ac.purbaya.projectcataloguemovie.fragment.AllMovieFragment;
import id.ac.purbaya.projectcataloguemovie.fragment.AllMovieGridFragment;
import id.ac.purbaya.projectcataloguemovie.fragment.FavoriteFragment;
import id.ac.purbaya.projectcataloguemovie.fragment.NowPlayingCardFragment;
import id.ac.purbaya.projectcataloguemovie.fragment.NowPlayingFragment;
import id.ac.purbaya.projectcataloguemovie.fragment.NowPlayingGridFragment;
import id.ac.purbaya.projectcataloguemovie.fragment.UpcomingCardFragment;
import id.ac.purbaya.projectcataloguemovie.fragment.UpcomingFragment;
import id.ac.purbaya.projectcataloguemovie.fragment.UpcomingGridFragment;

public class MainActivity extends AppCompatActivity  {


    private ViewPager viewPager;
private TabLayout tabLayout;
private ViewPagerAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        viewPager =  findViewById(R.id.viewpager);
        tabLayout = findViewById(R.id.tabs);
        adapter=new ViewPagerAdapter(getSupportFragmentManager());
        setupViewPagerCard(viewPager);
    }

    private void setupViewPager(ViewPager viewPager) {
        adapter.clear();

      adapter.addFragment(new AllMovieFragment(), getResources().getString(R.string.all_movie));
        adapter.addFragment(new NowPlayingFragment(), getResources().getString(R.string.now_playing));
        adapter.addFragment(new UpcomingFragment(), getResources().getString(R.string.upcoming));
        adapter.addFragment(new FavoriteFragment(),getResources().getString(R.string.favorite));

        viewPager.setAdapter(adapter);
        viewPager.getAdapter().notifyDataSetChanged();
        tabLayout.setupWithViewPager(viewPager);

    }

    private void setupViewPagerCard(ViewPager viewPager){
        adapter.clear();
        adapter.addFragment(new AllMovieCardFragment(), getResources().getString(R.string.all_movie));
        adapter.addFragment(new NowPlayingCardFragment(), getResources().getString(R.string.now_playing));
        adapter.addFragment(new UpcomingCardFragment(), getResources().getString(R.string.upcoming));
        adapter.addFragment(new FavoriteFragment(),getResources().getString(R.string.favorite));

        viewPager.setAdapter(adapter);
        viewPager.getAdapter().notifyDataSetChanged();
        tabLayout.setupWithViewPager(viewPager);

    }

    private void setupViewPagerGrid(ViewPager viewPager){
        adapter.clear();
        adapter.addFragment(new AllMovieGridFragment(), getResources().getString(R.string.all_movie));
        adapter.addFragment(new NowPlayingGridFragment(), getResources().getString(R.string.now_playing));
        adapter.addFragment(new UpcomingGridFragment(), getResources().getString(R.string.upcoming));
        adapter.addFragment(new FavoriteFragment(),getResources().getString(R.string.favorite));
        viewPager.setAdapter(adapter);
        viewPager.getAdapter().notifyDataSetChanged();
        tabLayout.setupWithViewPager(viewPager);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_setting:
                Intent mIntent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
                startActivity(mIntent);
                break;
            case R.id.action_list:
                setupViewPager(viewPager);
                break;

            case R.id.action_grid:
                setupViewPagerGrid(viewPager);
                break;

            case R.id.action_cardview:
                setupViewPagerCard(viewPager);
                break;
        }
        return super.onOptionsItemSelected(item);
    }



}
