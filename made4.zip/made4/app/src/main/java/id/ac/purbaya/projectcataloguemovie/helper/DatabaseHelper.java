package id.ac.purbaya.projectcataloguemovie.helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

import id.ac.purbaya.projectcataloguemovie.db.DatabaseContract;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static String DATABASE_NAME = "dbmovie";
    private static final int DATABASE_VERSION = 1;

    private static final String CREATE_TABLE=String.format("CREATE TABLE %s "+
                    " (%s INTEGER PRIMARY KEY AUTOINCREMENT," +
            "%s TEXT NOT NULL," +
            "%s TEXT NOT NULL," +
            "%s TEXT NOT NULL," +
            "%s TEXT NOT NULL," +
            "%s TEXT NOT NULL)",
            DatabaseContract.TABLE_FAVORITE,
            DatabaseContract.FavoriteColums._ID,
            DatabaseContract.FavoriteColums.ID_MOVIE,
            DatabaseContract.FavoriteColums.TITLE_MOVIE,
            DatabaseContract.FavoriteColums.DESC_MOVIE,
            DatabaseContract.FavoriteColums.DATE_MOVIE,
            DatabaseContract.FavoriteColums.POSTER_MOVIE);

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + DatabaseContract.TABLE_FAVORITE);
        onCreate(db);
    }
}
