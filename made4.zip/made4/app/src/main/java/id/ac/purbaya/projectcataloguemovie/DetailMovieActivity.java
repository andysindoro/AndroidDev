package id.ac.purbaya.projectcataloguemovie;

import android.app.LoaderManager;
import android.content.Intent;
import android.content.Loader;
import android.net.Uri;
import android.provider.Settings;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import id.ac.purbaya.projectcataloguemovie.helper.FavoriteHelper;
import id.ac.purbaya.projectcataloguemovie.loader.MovieDetailAsyncTaskLoader;
import id.ac.purbaya.projectcataloguemovie.model.Movie;
import id.ac.purbaya.projectcataloguemovie.model.MovieDetail;

public class DetailMovieActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<MovieDetail> {
    private ImageView imgView;
    private String url;
    private Movie movie;
    private TextView txtMJudul, txtMTitle, txtMPopularity, txtMLang, txtMRelease, txtMDesc, txtMGenre, txtMCountry;
private FavoriteHelper helper;
private Menu menuItem;
private LinearLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);
        helper=new FavoriteHelper(this);
        layout=findViewById(R.id.layout);


        //Identifikasi Komponen
        imgView = findViewById(R.id.imageView);
        txtMJudul = findViewById(R.id.txtMJudul);
        txtMTitle = findViewById(R.id.txtMTitle);
        txtMLang = findViewById(R.id.txtMLanguage);
        txtMPopularity = findViewById(R.id.txtMPopularity);
        txtMRelease = findViewById(R.id.txtMReleaseDate);
        txtMDesc = findViewById(R.id.txtMDesc);
        txtMGenre = findViewById(R.id.txtMGenre);
        txtMCountry = findViewById(R.id.txtMNegara);

        String idm = getIntent().getStringExtra("IDM");
        Bundle bundle = new Bundle();
        bundle.putString("IDM", idm);
        getLoaderManager().initLoader(0, bundle, this);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.setTitle(getIntent().getStringExtra("JUDUL"));
        imgView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent detail = new Intent(DetailMovieActivity.this, ViewPosterActivity.class);
                detail.putExtra("URL_POSTER", url);
                startActivity(detail);
            }
        });


    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @Override
    public Loader<MovieDetail> onCreateLoader(int i, Bundle args) {
        String movies = "";
        if (args != null) {
            movies = args.getString("IDM");
        }
        return new MovieDetailAsyncTaskLoader(this, movies);
    }

    @Override
    public void onLoadFinished(Loader<MovieDetail> loader, MovieDetail movieLists) {
        txtMDesc.setText(movieLists.getTxtDesc());
        txtMRelease.setText(movieLists.getTxtTanggal());
        txtMPopularity.setText(movieLists.getPopularity());
        txtMLang.setText(movieLists.getOriginal_language());
        txtMTitle.setText(movieLists.getTitle());
        txtMJudul.setText(movieLists.getTxtJudul());
        txtMGenre.setText(movieLists.getTxtGenre());
        txtMCountry.setText(movieLists.getTxtNegara());
        movie=new Movie();
        movie.setIdMovie(movieLists.getId());
        movie.setTitle(movieLists.getTitle());
        movie.setPoster(movieLists.getTxtPoster());
        movie.setDateRelase(movieLists.getTxtTanggal());
        movie.setOverview(movieLists.getTxtDesc());
        url = "http://image.tmdb.org/t/p/w185" + movieLists.getImageView();
        Glide.with(this).load(url).into(imgView);


        helper.open();
        setFavorite(helper.isFavorite(movie.getIdMovie()));
        helper.close();
    }

    @Override
    public void onLoaderReset(Loader<MovieDetail> loader) {
        txtMDesc.setText("");
        txtMRelease.setText("");
        txtMPopularity.setText("");
        txtMLang.setText("");
        txtMTitle.setText("");
        txtMJudul.setText("");
        imgView.setImageResource(R.drawable.ic_launcher_background);
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_share, menu);
        menuItem=menu;
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_setting:
                Intent mIntent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
                startActivity(mIntent);
                break;
            case R.id.action_share:
                String text = getResources().getString(R.string.app_name);
                Uri pictureUri = Uri.parse(url);
                Intent shareIntent = new Intent();
                shareIntent.setAction(Intent.ACTION_SEND);
                shareIntent.putExtra(Intent.EXTRA_TEXT, text);
                shareIntent.putExtra(Intent.EXTRA_STREAM, pictureUri);
                shareIntent.setType("image/*");
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(shareIntent, "Share..."));
                break;
            case R.id.action_favorite:
                helper.open();
                if(!helper.isFavorite(movie.getIdMovie())){
                    helper.insert(movie);
                    Snackbar.make(layout, "Added to Favorite", Snackbar.LENGTH_SHORT).show();
                }else{
                    helper.delete(movie.getIdMovie());
                    Snackbar.make(layout, "Remove to Favorite", Snackbar.LENGTH_SHORT).show();
                }
                setFavorite(helper.isFavorite(movie.getIdMovie()));
                helper.close();
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    public void setFavorite(boolean isFavorite){
        if(isFavorite){
            menuItem.getItem(2).setIcon(R.drawable.ic_added_to_favorites);
        }else{
            menuItem.getItem(2).setIcon(R.drawable.ic_add_to_favorites);
        }
    }
}