package id.ac.purbaya.projectcataloguemovie.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import id.ac.purbaya.projectcataloguemovie.R;
import id.ac.purbaya.projectcataloguemovie.adapter.MovieCardAdapter;
import id.ac.purbaya.projectcataloguemovie.loader.UpcomingAsyncLoader;
import id.ac.purbaya.projectcataloguemovie.model.Movie;

import java.util.ArrayList;


public class UpcomingCardFragment extends Fragment implements LoaderManager.LoaderCallbacks<ArrayList<Movie>> {

    RecyclerView rvCategory;
    private MovieCardAdapter adapter;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_upcoming, container, false);

        rvCategory = view.findViewById(R.id.listMovies);
        ArrayList<Movie> list = new ArrayList<>();
        rvCategory.setLayoutManager(new LinearLayoutManager(view.getContext()));

        adapter = new MovieCardAdapter(view.getContext());

        adapter.setListMovie(list);
        rvCategory.setAdapter(adapter);
        Bundle bundle = new Bundle();
        getLoaderManager().initLoader(0, bundle, this);
        return view;


    }

    @NonNull
    @Override
    public Loader<ArrayList<Movie>> onCreateLoader(int i, @Nullable Bundle bundle) {
        return new UpcomingAsyncLoader(getContext());
    }


    @Override
    public void onLoadFinished(@NonNull Loader<ArrayList<Movie>> loader, ArrayList<Movie> movies) {
        adapter.setListMovie(movies);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onLoaderReset(@NonNull Loader<ArrayList<Movie>> loader) {
        adapter.setListMovie(null);
    }


}

