package id.ac.purbaya.projectcataloguemovie.model;


public class MovieDetail {
    private String txtJudul, txtDesc, txtTanggal, imageView, id, title, popularity, original_language;
    private String txtGenre, txtRate, txtNegara, txtPoster;

    public String getTxtJudul() {
        return txtJudul;
    }

    public void setTxtJudul(String txtJudul) {
        this.txtJudul = txtJudul;
    }

    public String getTxtDesc() {
        return txtDesc;
    }

    public void setTxtDesc(String txtDesc) {
        this.txtDesc = txtDesc;
    }

    public String getTxtTanggal() {
        return txtTanggal;
    }

    public void setTxtTanggal(String txtTanggal) {
        this.txtTanggal = txtTanggal;
    }

    public String getImageView() {
        return imageView;
    }

    public void setImageView(String imageView) {
        this.imageView = imageView;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPopularity() {
        return popularity;
    }

    public void setPopularity(String popularity) {
        this.popularity = popularity;
    }

    public String getOriginal_language() {
        return original_language;
    }

    public void setOriginal_language(String original_language) {
        this.original_language = original_language;
    }

    public String getTxtGenre() {
        return txtGenre;
    }

    public void setTxtGenre(String txtGenre) {
        this.txtGenre = txtGenre;
    }



    public void setTxtRate(String txtRate) {
        this.txtRate = txtRate;
    }

    public String getTxtNegara() {
        return txtNegara;
    }

    public void setTxtNegara(String txtNegara) {
        this.txtNegara = txtNegara;
    }

    public String getTxtPoster() {
        return txtPoster;
    }

    public void setTxtPoster(String txtPoster) {
        this.txtPoster = txtPoster;
    }
}