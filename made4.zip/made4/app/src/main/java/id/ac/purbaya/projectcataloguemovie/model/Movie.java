package id.ac.purbaya.projectcataloguemovie.model;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import id.ac.purbaya.projectcataloguemovie.db.DatabaseContract;

import static android.provider.BaseColumns._ID;
import static id.ac.purbaya.projectcataloguemovie.db.DatabaseContract.getColumnInt;
import static id.ac.purbaya.projectcataloguemovie.db.DatabaseContract.getColumnString;

public class Movie implements Parcelable {

    public Movie() {
    }

    private String idMovie, poster, title, overview, dateRelase;
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIdMovie() {
        return idMovie;
    }

    public void setIdMovie(String idMovie) {
        this.idMovie = idMovie;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getDateRelase() {
        return dateRelase;
    }

    public void setDateRelase(String dateRelase) {
        this.dateRelase = dateRelase;
    }

    public Movie(Cursor cursor) {
        this.id = getColumnInt(cursor, _ID);
        this.title = getColumnString(cursor, DatabaseContract.FavoriteColums.TITLE_MOVIE);
        this.overview = getColumnString(cursor, DatabaseContract.FavoriteColums.DESC_MOVIE);
        this.dateRelase = getColumnString(cursor, DatabaseContract.FavoriteColums.DATE_MOVIE);
        this.idMovie = getColumnString(cursor, DatabaseContract.FavoriteColums.ID_MOVIE);
        this.poster = getColumnString(cursor, DatabaseContract.FavoriteColums.POSTER_MOVIE);
    }

    protected Movie (Parcel in){
        this.id = in.readInt();
        this.title = in.readString();
        this.overview = in.readString();
        this.dateRelase = in.readString();
        this.idMovie = in.readString();
        this.poster = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.id);
        dest.writeString(this.title);
        dest.writeString(this.idMovie);
        dest.writeString(this.dateRelase);
        dest.writeString(this.overview);
        dest.writeString(this.poster);
    }

    public static final Parcelable.Creator<Movie> CREATOR = new Parcelable.Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel source) {
            return new Movie(source);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };
}
