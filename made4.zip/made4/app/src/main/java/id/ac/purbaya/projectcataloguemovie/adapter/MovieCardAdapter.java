package id.ac.purbaya.projectcataloguemovie.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import id.ac.purbaya.projectcataloguemovie.DetailMovieActivity;
import id.ac.purbaya.projectcataloguemovie.R;
import id.ac.purbaya.projectcataloguemovie.helper.FavoriteHelper;
import id.ac.purbaya.projectcataloguemovie.model.Movie;
import id.ac.purbaya.projectcataloguemovie.utils.CustomOnItemClickListener;

import java.util.ArrayList;

public class MovieCardAdapter extends RecyclerView.Adapter<MovieCardAdapter.MovieViewHolder> {
    private Context context;
    private ArrayList<Movie> listMoview;
    private String url;
    private FavoriteHelper helper;



    private ArrayList<Movie> getListMovie() {
        return listMoview;
    }

    public void setListMovie(ArrayList<Movie> listMoview) {
        this.listMoview = listMoview;
    }


    public MovieCardAdapter(Context context) {
        this.context = context;
        helper=new FavoriteHelper(context);
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemRow = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_list_movie, parent, false);

        return new MovieViewHolder(itemRow);
    }


    @Override
    public void onBindViewHolder(@NonNull final MovieViewHolder holder, int position) {
        holder.bind(listMoview.get(position));

        holder.btnDetail.setOnClickListener(new CustomOnItemClickListener(position, new CustomOnItemClickListener.OnItemClickCallback() {
            @Override
            public void onItemClicked(View view, int position) {
                Intent detail=new Intent(view.getContext(),DetailMovieActivity.class);
                detail.putExtra("IDM",listMoview.get(position).getIdMovie());
                detail.putExtra("JUDUL",listMoview.get(position).getTitle());
                view.getContext().startActivity(detail);
            }
        }));

        holder.btnShare.setOnClickListener(new CustomOnItemClickListener(position, new CustomOnItemClickListener.OnItemClickCallback() {
            @Override
            public void onItemClicked(View view, int position) {
                String text = context.getResources().getString(R.string.app_name);
                Uri pictureUri = Uri.parse(url);
                Intent shareIntent = new Intent();
                shareIntent.setAction(Intent.ACTION_SEND);
                shareIntent.putExtra(Intent.EXTRA_TEXT, text);
                shareIntent.putExtra(Intent.EXTRA_STREAM, pictureUri);
                shareIntent.setType("image/*");
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                context.startActivity(Intent.createChooser(shareIntent, "Share..."));
            }
        }));

        holder.btnFavorite.setOnClickListener(new CustomOnItemClickListener(position, new CustomOnItemClickListener.OnItemClickCallback() {
            @Override
            public void onItemClicked(View view, int position) {
                helper.open();
                if(!helper.isFavorite(listMoview.get(position).getIdMovie())){
                    helper.insert(listMoview.get(position));
                    Snackbar.make(view, "Added to Favorite", Snackbar.LENGTH_SHORT).show();
                }else{
                    helper.delete(listMoview.get(position).getIdMovie());
                    Snackbar.make(view, "Remove to Favorite", Snackbar.LENGTH_SHORT).show();
                }
                setFavorite(holder,helper.isFavorite(listMoview.get(position).getIdMovie()));
                helper.close();
            }
        }));
    }

    @Override
    public int getItemCount() {
        return getListMovie().size();
    }

    class MovieViewHolder extends RecyclerView.ViewHolder {
        TextView tvJudul;
        TextView tvDesc;
        TextView tvDateRelease;
        ImageView imgPoster;
        ImageButton btnDetail;
        ImageButton btnShare;
        ImageButton btnFavorite;


        MovieViewHolder(View itemView) {
            super(itemView);
            tvJudul = itemView.findViewById(R.id.tv_title);
            tvDesc = itemView.findViewById(R.id.tv_desc);
            tvDateRelease = itemView.findViewById(R.id.tv_date_release);
            imgPoster = itemView.findViewById(R.id.imgPoster);
            btnDetail=itemView.findViewById(R.id.btn_set_detail);
            btnShare=itemView.findViewById(R.id.btn_set_share);
            btnFavorite=itemView.findViewById(R.id.btn_favorite);

        }

        private void bind(final Movie item) {
            tvJudul.setText(item.getTitle());
            tvDateRelease.setText(item.getDateRelase());
            String desc = item.getOverview();
            if (desc.length() >= 100) {
                desc = desc.substring(0, 100);
            }
            tvDesc.setText(desc);
            url = "http://image.tmdb.org/t/p/w185" + item.getPoster();
            Glide.with(context)
                    .load(url)
                    .into(imgPoster);
            helper.open();
            if(helper.isFavorite(item.getIdMovie())){
                btnFavorite.setImageResource(R.drawable.ic_added_to_favorites);
            }else{
                btnFavorite.setImageResource(R.drawable.ic_add_to_favorites);
            }
            helper.close();

        }
    }

    private void setFavorite(MovieViewHolder holder,boolean isFavorite){
        if(isFavorite){
            holder.btnFavorite.setImageResource(R.drawable.ic_added_to_favorites);
        }else{
            holder.btnFavorite.setImageResource(R.drawable.ic_add_to_favorites);
        }
    }
}
