package id.ac.purbaya.modulcataloguemovie;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import id.ac.purbaya.modulcataloguemovie.db.DatabaseContract;
import id.ac.purbaya.modulcataloguemovie.db.DatabaseHelper;

import java.util.ArrayList;

import static android.provider.BaseColumns._ID;

public class FavoriteHelper {
    private Context context;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    public FavoriteHelper(Context context) {
        this.context = context;
    }

    public FavoriteHelper open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public ArrayList<Movie> query() {
        ArrayList<Movie> movies = new ArrayList<>();
        Cursor cursor = database.query(DatabaseContract.TABLE_FAVORITE, null,
                null, null, null, null, _ID + " DESC");
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            Movie movie;
            do {
                movie = new Movie();
                movie.setId(cursor.getInt(cursor.getColumnIndexOrThrow(_ID)));
                movie.setIdMovie(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.FavoriteColums.ID_MOVIE)));
                movie.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.FavoriteColums.TITLE_MOVIE)));
                movie.setOverview(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.FavoriteColums.DESC_MOVIE)));
                movie.setDateRelase(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.FavoriteColums.DATE_MOVIE)));
                movie.setPoster(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.FavoriteColums.POSTER_MOVIE)));
                movies.add(movie);
                cursor.moveToNext();
            } while (!cursor.isAfterLast());
        }
        cursor.close();
        return movies;
    }

    public long insert(Movie movie) {
        ContentValues args = new ContentValues();
        args.put(DatabaseContract.FavoriteColums.ID_MOVIE, movie.getIdMovie());
        args.put(DatabaseContract.FavoriteColums.TITLE_MOVIE, movie.getTitle());
        args.put(DatabaseContract.FavoriteColums.DESC_MOVIE, movie.getOverview());
        args.put(DatabaseContract.FavoriteColums.DATE_MOVIE, movie.getDateRelase());
        args.put(DatabaseContract.FavoriteColums.POSTER_MOVIE, movie.getPoster());
        Log.i("DATABASE INSERT", movie.getIdMovie());
        return database.insert(DatabaseContract.TABLE_FAVORITE, null, args);
    }

    public int update(Movie movie) {
        ContentValues args = new ContentValues();
        args.put(DatabaseContract.FavoriteColums.ID_MOVIE, movie.getIdMovie());
        args.put(DatabaseContract.FavoriteColums.TITLE_MOVIE, movie.getIdMovie());
        args.put(DatabaseContract.FavoriteColums.DESC_MOVIE, movie.getIdMovie());
        args.put(DatabaseContract.FavoriteColums.DATE_MOVIE, movie.getIdMovie());
        args.put(DatabaseContract.FavoriteColums.POSTER_MOVIE, movie.getIdMovie());
        return database.update(DatabaseContract.TABLE_FAVORITE, args, _ID + "= '" + movie.getId() + "'", null);
    }

    public int delete(String idMovie) {
        return database.delete(DatabaseContract.TABLE_FAVORITE,
                DatabaseContract.FavoriteColums.ID_MOVIE + " = '" + idMovie + "'", null);
    }

    public boolean isFavorite(String idMovie) {
        boolean ada = false;
        Cursor cursor = database.query(DatabaseContract.TABLE_FAVORITE, null,
                DatabaseContract.FavoriteColums.ID_MOVIE + "=?", new String[]{idMovie},
                null, null, _ID + " DESC");
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            ada = true;
        }
        return ada;
    }

    public Cursor queryByIdProvider(String id) {
        return database.query(DatabaseContract.TABLE_FAVORITE, null
                , _ID + " = ?"
                , new String[]{id}
                , null
                , null
                , null
                , null);
    }

    public Cursor queryProvider() {
        return database.query(DatabaseContract.TABLE_FAVORITE
                , null
                , null
                , null
                , null
                , null
                , _ID + " DESC");
    }

    public long insertProvider(ContentValues values) {
        return database.insert(DatabaseContract.TABLE_FAVORITE, null, values);
    }

    public int updateProvider(String idMovie, ContentValues values) {
        return database.update(DatabaseContract.TABLE_FAVORITE, values, _ID + " = ?", new String[]{idMovie});
    }

    public int deleteProvider(String idMovie) {
        return database.delete(DatabaseContract.TABLE_FAVORITE, _ID + " = ?", new String[]{idMovie});
    }
}
