package id.ac.purbaya.modulcataloguemovie.db;

import android.database.Cursor;
import android.net.Uri;
import android.provider.BaseColumns;

public class DatabaseContract {
    public static String TABLE_FAVORITE="favorite";

    public static final class FavoriteColums implements BaseColumns{
        public static String ID_MOVIE="id_movie";
        public static String TITLE_MOVIE="title_movie";
        public static String DESC_MOVIE="desc_movie";
        public static String DATE_MOVIE="date_movie";
        public static String POSTER_MOVIE="poster_movie";

    }

    public static final String AUTHORITY = "id.ac.purbaya.projectcataloguemovie";
    public static final Uri CONTENT_URI = new Uri.Builder().scheme("content")
            .authority(AUTHORITY)
            .appendPath(TABLE_FAVORITE)
            .build();
    public static String getColumnString(Cursor cursor, String columnName) {
        return cursor.getString( cursor.getColumnIndex(columnName) );
    }
    public static int getColumnInt(Cursor cursor, String columnName) {
        return cursor.getInt( cursor.getColumnIndex(columnName) );
    }
    public static long getColumnLong(Cursor cursor, String columnName) {
        return cursor.getLong( cursor.getColumnIndex(columnName) );
    }
}
