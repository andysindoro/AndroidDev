package id.ac.purbaya.modulcataloguemovie;


import android.content.AsyncTaskLoader;
import android.content.Context;
import android.util.Log;

import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.SyncHttpClient;

import org.json.JSONArray;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

import static id.ac.purbaya.modulcataloguemovie.BuildConfig.API_KEY;

public class MovieDetailAsyncTaskLoader extends AsyncTaskLoader<MovieDetail> {
    private MovieDetail mData;
    private boolean mHasResult = false;


    private String idm;

    public MovieDetailAsyncTaskLoader(final Context context, String idm) {
        super(context);
        onContentChanged();
        this.idm = idm;
    }

    @Override
    protected void onStartLoading() {
        if (takeContentChanged())
            forceLoad();
        else if (mHasResult)
            deliverResult(mData);
    }

    @Override
    public void deliverResult(final MovieDetail data) {
        mData = data;
        mHasResult = true;
        super.deliverResult(data);
    }

    @Override
    protected void onReset() {
        super.onReset();
        onStopLoading();
        if (mHasResult) {
            mData = null;
            mHasResult = false;
        }
    }


    @Override
    public MovieDetail loadInBackground() {
        SyncHttpClient client = new SyncHttpClient();

        String url = "https://api.themoviedb.org/3/movie/"+idm+"?api_key="+API_KEY+"&language=en-US";

        Log.i("URL MOVIE: ",url);

        client.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                setUseSynchronousMode(true);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    String result = new String(responseBody);
                    JSONObject responseObject = new JSONObject(result);
                    mData = new MovieDetail();
                    mData.setId(responseObject.getString("id"));
                    mData.setTitle(responseObject.getString("title"));
                   mData.setTxtDesc(responseObject.getString("overview"));
                    mData.setTxtTanggal(responseObject.getString("release_date"));
                    mData.setTxtPoster(responseObject.getString("poster_path"));
                    mData.setOriginal_language(responseObject.getString("original_language"));
                    mData.setPopularity(responseObject.getString("popularity"));
                    mData.setImageView(responseObject.getString("poster_path"));
                   mData.setTxtRate(responseObject.getString("vote_average"));
                    JSONArray list = responseObject.getJSONArray("genres");
                    String genre="";
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < list.length(); i++) {
                        JSONObject gen = list.getJSONObject(i);
                        genre= String.valueOf(sb.append(" ").append(gen.getString("name")));
                    }
                   mData.setTxtGenre(genre);

                    JSONArray list2 = responseObject.getJSONArray("production_countries");
                    String negara="";
                    for (int i = 0; i < list2.length(); i++) {
                        JSONObject aa = list2.getJSONObject(i);
                        negara=String.valueOf(sb.append(" ").append(aa.getString("name")));
                    }
                    mData.setTxtNegara(negara);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }


            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.i("GAGAL LOAD DATA", error.getMessage());
            }
        });

        return mData;
    }

}