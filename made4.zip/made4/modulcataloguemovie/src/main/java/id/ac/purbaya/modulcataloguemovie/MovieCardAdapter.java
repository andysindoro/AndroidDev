package id.ac.purbaya.modulcataloguemovie;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.v4.widget.CursorAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import id.ac.purbaya.modulcataloguemovie.db.DatabaseContract;

import static id.ac.purbaya.modulcataloguemovie.db.DatabaseContract.getColumnString;

public class MovieCardAdapter extends CursorAdapter {

    public MovieCardAdapter(Context context, Cursor c, boolean autoRequery) {
        super(context, c, autoRequery);
    }

    @Override
    public Cursor getCursor() {
        return super.getCursor();
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        return LayoutInflater.from(context).inflate(R.layout.card_list_movie, viewGroup, false);

    }

    @Override
    public void bindView(View itemView, final Context context, Cursor cursor) {
        if (cursor != null) {
            final TextView tvJudul;
            TextView tvDesc;
            TextView tvDateRelease;
            ImageView imgPoster;
            ImageButton btnDetail;
            ImageButton btnShare;

            tvJudul = itemView.findViewById(R.id.tv_title);
            tvDesc = itemView.findViewById(R.id.tv_desc);
            tvDateRelease = itemView.findViewById(R.id.tv_date_release);
            imgPoster = itemView.findViewById(R.id.imgPoster);
            btnDetail=itemView.findViewById(R.id.btn_set_detail);
            btnShare=itemView.findViewById(R.id.btn_set_share);

            tvJudul.setText(getColumnString(cursor,DatabaseContract.FavoriteColums.TITLE_MOVIE));
            tvDateRelease.setText(getColumnString(cursor,DatabaseContract.FavoriteColums.DATE_MOVIE));
            String desc = getColumnString(cursor,DatabaseContract.FavoriteColums.DESC_MOVIE);
            if (desc.length() >= 100) {
                desc = desc.substring(0, 100);
            }
            tvDesc.setText(desc);
            final String  url = "http://image.tmdb.org/t/p/w185" + getColumnString(cursor,DatabaseContract.FavoriteColums.POSTER_MOVIE);
            Glide.with(context)
                    .load(url)
                    .into(imgPoster);
            Log.i("IMAGE URL",url);

            final String idMovie=getColumnString(cursor,DatabaseContract.FavoriteColums.ID_MOVIE);

            btnDetail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent detail=new Intent(view.getContext(),DetailMovieActivity.class);
                    detail.putExtra("IDM",idMovie);
                    detail.putExtra("JUDUL",tvJudul.getText().toString());
                    view.getContext().startActivity(detail);
                }
            });

            btnShare.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String text = context.getResources().getString(R.string.app_name);
                    Uri pictureUri = Uri.parse(url);
                    Intent shareIntent = new Intent();
                    shareIntent.setAction(Intent.ACTION_SEND);
                    shareIntent.putExtra(Intent.EXTRA_TEXT, text);
                    shareIntent.putExtra(Intent.EXTRA_STREAM, pictureUri);
                    shareIntent.setType("image/*");
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    context.startActivity(Intent.createChooser(shareIntent, "Share..."));
                }
            });
        }
    }
}
