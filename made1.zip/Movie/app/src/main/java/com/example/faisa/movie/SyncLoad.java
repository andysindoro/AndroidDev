package com.example.faisa.movie;

import android.content.AsyncTaskLoader;
import android.content.Context;

import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.SyncHttpClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


import cz.msebera.android.httpclient.Header;

public class SyncLoad extends AsyncTaskLoader<List<FilmItems>>
{
    private List<FilmItems> dataFilm;
    private boolean result = false;

    private String titleFilm;

    public SyncLoad(final Context context, String nameFilm)
    {
        super(context);

        onContentChanged();
        this.titleFilm = nameFilm;
    }

    @Override
    protected void onStartLoading()
    {
        if(takeContentChanged())
        {
            forceLoad();
        }
        else if(result)
        {
            deliverResult(dataFilm);
        }
    }

    @Override
    public void deliverResult(List<FilmItems> data)
    {
        dataFilm = data;
        result = true;
        super.deliverResult(data);
    }

    @Override
    protected void onReset()
    {
        super.onReset();
        onStopLoading();
        if(result)
        {
            dataFilm = null;
            result = false;
        }

    }

    private static final String API_KEY = "810ce0bfd1cdcde76bdd6124a11564f1";

    @Override
    public List<FilmItems> loadInBackground()
    {
        SyncHttpClient client = new SyncHttpClient();

        final List<FilmItems> filmItemses = new ArrayList<>();

        String url = "https://api.themoviedb.org/3/search/movie?api_key=" +API_KEY+"&language=en-US&query="+titleFilm;

        client.get(url, new AsyncHttpResponseHandler()
        {
            @Override
            public void onStart()
            {
                super.onStart();
                setUseSynchronousMode(true);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody)
            {
                try
                {
                    String result = new String(responseBody);
                    JSONObject responseObject = new JSONObject(result);
                    JSONArray list = responseObject.getJSONArray("results");

                    for(int i=0; i<list.length(); i++)
                    {
                        JSONObject film = list.getJSONObject(i);
                        FilmItems filmItems = new FilmItems(film);
                        filmItemses.add(filmItems);
                    }
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error)
            {

            }
        });
        return filmItemses;
    }
}