package com.example.faisa.movie;

import android.app.LoaderManager;
import android.content.Intent;
import android.content.Loader;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.List;


public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<FilmItems>>
{
    ListView listView;
    FilmAdapter adapter;
    ImageView ivImageFilm;
    Button btnSearchFilm;
    EditText edFilm;

    static final String EXTRA_FILM = "EXTRA_FILM";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.lvCataogueFilm);
        edFilm = findViewById(R.id.edSearchFilm);
        btnSearchFilm = findViewById(R.id.btnSearchFilm);
        ivImageFilm = findViewById(R.id.ivImageFilm);

        String filmName = edFilm.getText().toString();

        adapter = new FilmAdapter(this);
        adapter.notifyDataSetChanged();

        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long l)
            {
                FilmItems item = (FilmItems) parent.getItemAtPosition(position);

                Intent intent = new Intent(MainActivity.this, DetailFilm.class);

                intent.putExtra(DetailFilm.EXTRA_NAME, item.getFilmName());
                intent.putExtra(DetailFilm.EXTRA_IMAGE,item.getImageFilm());
                intent.putExtra(DetailFilm.EXTRA_LANGUAGE,item.getFilmLanguage());
                intent.putExtra(DetailFilm.EXTRA_AVERAGE,item.getFilmRate());
                intent.putExtra(DetailFilm.EXTRA_SYNOPSIS,item.getFilmSynopsis());
                intent.putExtra(DetailFilm.EXTRA_DATETIME,item.getFilmDateTime());

                startActivity(intent);
            }
        });


        btnSearchFilm.setOnClickListener(filmListener);

        Bundle bundle = new Bundle();
        bundle.putString(EXTRA_FILM, filmName);

        getLoaderManager().initLoader(0, bundle, this);
    }

    @Override
    public Loader<List<FilmItems>> onCreateLoader(int i, Bundle bundle)
    {
        String filmName = "";
        if(bundle != null)
        {
            filmName = bundle.getString(EXTRA_FILM);
        }
        return new SyncLoad(this, filmName);
    }

    @Override
    public void onLoadFinished(Loader<List<FilmItems>> loader, List<FilmItems> filmItems)
    {
        Log.d("moviesize", "onLoadFinished: " + filmItems.size());
        adapter.setData(filmItems);
    }

    @Override
    public void onLoaderReset(Loader<List<FilmItems>> loader)
    {
        adapter.setData(null);
    }

    View.OnClickListener filmListener= new View.OnClickListener()
    {
        @Override
        public void onClick(View view)
        {
            String filmName = edFilm.getText().toString();
            if(TextUtils.isEmpty(filmName))
            {
                return;
            }



            Bundle bundle = new Bundle();
            bundle.putString(EXTRA_FILM, filmName);
            getLoaderManager().restartLoader(0, bundle, MainActivity.this);
        }
    };
}